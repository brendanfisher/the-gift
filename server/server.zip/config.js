module.exports = {
    dbURL: process.env.DB_URL || 'localhost',
    dbUsername: process.env.DB_USERNAME || 'root',
    dbPassword: process.env.DB_PASSWORD || 'test'
};