async function saveImage(filename, image, ext) {
}

async function getVideoURL(id) {
    return null;
}

async function createVideo(id) {
    //TODO: spin up video process
}

module.exports = {
    saveImage,
    getVideoURL,
    createVideo
};